import '../../domain/weather_entity.dart';
import 'season_service.dart';
import 'pest_risk_service.dart';

class FarmingTask {
  final String title;
  final String priority;
  final String description;
  final bool completed;

  const FarmingTask({
    required this.title,
    required this.priority,
    required this.description,
    this.completed = false,
  });
}

class FarmingTaskService {
  static List<FarmingTask> generate({
    required WeatherEntity weather,
    required SeasonResult season,
    required PestRiskResult pestRisk,
  }) {
    final List<FarmingTask> tasks = [];

    // ----------------------------
    // Weather Based
    // ----------------------------

    if (weather.weatherCode >= 61 &&
        weather.weatherCode <= 67) {
      tasks.add(
        const FarmingTask(
          title: "Inspect Field Drainage",
          priority: "High",
          description:
              "Heavy rainfall is expected. Ensure drainage canals are clear.",
        ),
      );
    }

    // ----------------------------
    // Temperature
    // ----------------------------

    if (weather.temperature >= 30) {
      tasks.add(
        const FarmingTask(
          title: "Monitor Soil Moisture",
          priority: "Medium",
          description:
              "High temperatures may dry the upper soil layer.",
        ),
      );
    }

    // ----------------------------
    // Pest Risk
    // ----------------------------

    if (pestRisk.level == "High" ||
        pestRisk.level == "Very High") {
      tasks.add(
        FarmingTask(
          title: "Inspect for ${pestRisk.possiblePest}",
          priority: "High",
          description: pestRisk.recommendation,
        ),
      );
    }

    // ----------------------------
    // Season
    // ----------------------------

    if (season.name == "Wet Season") {
      tasks.add(
        const FarmingTask(
          title: "Maintain Water Level",
          priority: "Medium",
          description:
              "Maintain proper water depth in rice paddies.",
        ),
      );
    } else {
      tasks.add(
        const FarmingTask(
          title: "Check Irrigation",
          priority: "High",
          description:
              "Ensure irrigation is sufficient during the dry season.",
        ),
      );
    }

    // ----------------------------
    // Daily Reminder
    // ----------------------------

    tasks.add(
      const FarmingTask(
        title: "Review Tomorrow's Forecast",
        priority: "Low",
        description:
            "Prepare field activities based on tomorrow's weather.",
      ),
    );

    return tasks;
  }
}