import 'crop_stage_service.dart';

enum HarvestStatus {
  onSchedule,
  slightlyDelayed,
  delayed,
  ready,
}

class HarvestResult {
  final DateTime expectedHarvestDate;
  final int daysRemaining;
  final double progress;
  final HarvestStatus status;
  final String statusMessage;

  const HarvestResult({
    required this.expectedHarvestDate,
    required this.daysRemaining,
    required this.progress,
    required this.status,
    required this.statusMessage,
  });
}

class HarvestService {
  static const int cropDuration = 120;

  static HarvestResult evaluate({
    required DateTime plantingDate,
    required CropStageResult cropStage,
    int weatherDelayDays = 0,
  }) {
    final expectedHarvest =
        plantingDate.add(Duration(days: cropDuration + weatherDelayDays));

    final today = DateTime.now();

    int remaining =
        expectedHarvest.difference(today).inDays;

    if (remaining < 0) {
      remaining = 0;
    }

    double progress =
        (cropStage.dayNumber / cropDuration) * 100;

    if (progress > 100) {
      progress = 100;
    }

    HarvestStatus status;
    String message;

    if (remaining == 0) {
      status = HarvestStatus.ready;
      message = "Rice crop is ready for harvest.";
    } else if (weatherDelayDays >= 7) {
      status = HarvestStatus.delayed;
      message =
          "Harvest may be delayed due to unfavorable weather conditions.";
    } else if (weatherDelayDays >= 3) {
      status = HarvestStatus.slightlyDelayed;
      message =
          "Slight harvest delay is possible. Continue monitoring.";
    } else {
      status = HarvestStatus.onSchedule;
      message =
          "Crop development is on schedule.";
    }

    return HarvestResult(
      expectedHarvestDate: expectedHarvest,
      daysRemaining: remaining,
      progress: progress,
      status: status,
      statusMessage: message,
    );
  }
}