class SeasonResult {
  final String name;
  final String description;
  final String tip;
  final bool isPlantingSeason;

  const SeasonResult({
    required this.name,
    required this.description,
    required this.tip,
    required this.isPlantingSeason,
  });
}

class SeasonService {
  static SeasonResult getCurrentSeason() {
    final now = DateTime.now();
    final month = now.month;

    // Philippines (PAGASA)
    // Wet Season: June - November
    // Dry Season: December - May

    if (month >= 6 && month <= 11) {
      return const SeasonResult(
        name: 'Wet Season',
        description: 'Rainfall is generally sufficient for rice cultivation.',
        tip:
            'Maintain proper drainage and regularly inspect fields for fungal diseases and pests.',
        isPlantingSeason: true,
      );
    }

    return const SeasonResult(
      name: 'Dry Season',
      description: 'Limited rainfall. Irrigation is essential.',
      tip:
          'Monitor soil moisture regularly and ensure irrigation is available before planting.',
      isPlantingSeason: true,
    );
  }
}