import '../../domain/weather_entity.dart';
import 'season_service.dart';

class PlantingScoreResult {
  final double totalScore;
  final String rating;
  final List<String> reasons;

  const PlantingScoreResult({
    required this.totalScore,
    required this.rating,
    required this.reasons,
  });
}

class PlantingScoreService {
  static PlantingScoreResult evaluate({
    required WeatherEntity weather,
    required SeasonResult season,
  }) {
    double score = 100;
    List<String> reasons = [];

    // -------------------------
    // TEMPERATURE
    // -------------------------

    if (weather.temperature >= 25 &&
        weather.temperature <= 32) {
      reasons.add("Ideal temperature for rice growth.");
    } else {
      score -= 15;
      reasons.add("Temperature is outside the ideal range.");
    }

    // -------------------------
    // HUMIDITY
    // -------------------------

    if (weather.humidity >= 70 &&
        weather.humidity <= 90) {
      reasons.add("Humidity is suitable.");
    } else {
      score -= 10;
      reasons.add("Humidity is less favorable.");
    }

    // -------------------------
    // WEATHER CODE
    // -------------------------

    if (weather.weatherCode >= 95) {
      score -= 35;
      reasons.add("Thunderstorm detected.");
    } else if (weather.weatherCode >= 61 &&
        weather.weatherCode <= 67) {
      score -= 20;
      reasons.add("Heavy rainfall expected.");
    }

    // -------------------------
    // SEASON
    // -------------------------

    if (season.isPlantingSeason) {
      reasons.add("Current season supports rice planting.");
    } else {
      score -= 20;
      reasons.add("Current season is not ideal.");
    }

    if (score < 0) score = 0;

    String rating;

    if (score >= 90) {
      rating = "Excellent";
    } else if (score >= 75) {
      rating = "Good";
    } else if (score >= 60) {
      rating = "Fair";
    } else {
      rating = "Poor";
    }

    return PlantingScoreResult(
      totalScore: score,
      rating: rating,
      reasons: reasons,
    );
  }
}