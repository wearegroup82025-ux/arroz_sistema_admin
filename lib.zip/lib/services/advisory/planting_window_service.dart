import '../../domain/weather_entity.dart';
import 'season_service.dart';
import 'planting_score_service.dart';

class PlantingWindowResult {
  final DateTime bestDate;
  final int goodDays;
  final int fairDays;
  final int badDays;

  const PlantingWindowResult({
    required this.bestDate,
    required this.goodDays,
    required this.fairDays,
    required this.badDays,
  });
}

class PlantingWindowService {
  static PlantingWindowResult generate({
    required WeatherEntity weather,
    required SeasonResult season,
  }) {
    int good = 0;
    int fair = 0;
    int bad = 0;

    DateTime bestDate = DateTime.now();
    double highestScore = -1;

    for (final day in weather.forecast) {
      double score = 100;

      // Temperature
      final avgTemp = (day.maxTemp + day.minTemp) / 2;

      if (avgTemp < 25 || avgTemp > 32) {
        score -= 15;
      }

      // Weather condition
      if (day.weatherCode >= 61 &&
          day.weatherCode <= 67) {
        score -= 20;
      }

      if (day.weatherCode >= 95) {
        score -= 40;
      }

      // Season
      if (!season.isPlantingSeason) {
        score -= 20;
      }

      if (score >= 80) {
        good++;
      } else if (score >= 60) {
        fair++;
      } else {
        bad++;
      }

      if (score > highestScore) {
        highestScore = score;
        bestDate = DateTime.parse(day.date);
      }
    }

    return PlantingWindowResult(
      bestDate: bestDate,
      goodDays: good,
      fairDays: fair,
      badDays: bad,
    );
  }
}