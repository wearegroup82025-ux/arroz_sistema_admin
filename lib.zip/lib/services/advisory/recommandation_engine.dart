import '../../domain/weather_entity.dart';
import 'planting_score_service.dart';
import 'season_service.dart';

class RecommendationResult {
  final String title;
  final String message;
  final String action;
  final double confidence;
  final List<String> reasons;
  final String advisory;

  const RecommendationResult({
    required this.title,
    required this.message,
    required this.action,
    required this.confidence,
    required this.reasons,
    required this.advisory,
  });
}

class RecommendationEngine {
  static RecommendationResult generate({
    required WeatherEntity weather,
    required PlantingScoreResult plantingScore,
    required SeasonResult season,
  }) {
    String title;
    String message;
    String action;
    String advisory = "No active weather advisory.";
    double confidence;

    if (plantingScore.totalScore >= 90) {
      title = "🌱 Excellent Planting Conditions";
      message =
          "Current environmental conditions are highly favorable for rice planting.";
      action = "Proceed with planting today.";
      confidence = 98;
    } else if (plantingScore.totalScore >= 75) {
      title = "✅ Good Planting Conditions";
      message =
          "Current conditions are generally suitable for rice planting.";
      action = "Planting is recommended.";
      confidence = 90;
    } else if (plantingScore.totalScore >= 60) {
      title = "⚠ Fair Planting Conditions";
      message =
          "Some environmental factors require attention before planting.";
      action = "Monitor weather before planting.";
      confidence = 75;
    } else {
      title = "❌ Poor Planting Conditions";
      message =
          "Current conditions are not suitable for rice planting.";
      action = "Delay planting until conditions improve.";
      confidence = 60;
    }

    if (weather.weatherCode >= 95) {
      advisory =
          "Thunderstorm detected. Avoid field activities.";
    } else if (weather.weatherCode >= 61 &&
        weather.weatherCode <= 67) {
      advisory =
          "Heavy rainfall expected. Delay planting if possible.";
    }

    return RecommendationResult(
      title: title,
      message: message,
      action: action,
      confidence: confidence,
      reasons: plantingScore.reasons,
      advisory: advisory,
    );
  }
}