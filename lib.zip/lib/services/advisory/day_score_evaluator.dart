import '../../domain/weather_entity.dart';
import 'advisory_rules.dart';
import 'season_service.dart';

class DayScoreResult {
  final int totalScore;

  final int seasonScore;
  final int temperatureScore;
  final int rainfallScore;
  final int humidityScore;
  final int windScore;
  final int stormScore;
  final int soilScore;

  final String level;

  final List<String> reasons;

  final List<String> warnings;

  const DayScoreResult({
    required this.totalScore,
    required this.seasonScore,
    required this.temperatureScore,
    required this.rainfallScore,
    required this.humidityScore,
    required this.windScore,
    required this.stormScore,
    required this.soilScore,
    required this.level,
    required this.reasons,
    required this.warnings,
  });
}

class DayScoreEvaluator {
  static DayScoreResult evaluate({
    required WeatherEntity weather,
    required DailyForecastEntity day,
  }) {
    final season =
        SeasonService.evaluate(DateTime.parse(day.date));

    int seasonScore =
        season.isRecommended
            ? AdvisoryRules.seasonWeight
            : 10;

    int temperatureScore = _temperature(day.maxTemp);

    int rainfallScore = _rainfall(day.rainfall);

    int humidityScore = _humidity(weather.humidity);

    int windScore = _wind(day.windSpeed);

    int stormScore =
        day.weatherCode >= 95
            ? 0
            : AdvisoryRules.stormWeight;

    int soilScore =
        _soil(day.rainfall, weather.humidity);

    int total =
        seasonScore +
        temperatureScore +
        rainfallScore +
        humidityScore +
        windScore +
        stormScore +
        soilScore;

    String level;

    if (total >= 90) {
      level = "Excellent";
    } else if (total >= 75) {
      level = "Good";
    } else if (total >= 60) {
      level = "Fair";
    } else {
      level = "Poor";
    }

    List<String> reasons = [];

    if (seasonScore == 25) {
      reasons.add("Suitable planting season");
    }

    if (temperatureScore >= 15) {
      reasons.add("Ideal temperature");
    }

    if (rainfallScore >= 15) {
      reasons.add("Adequate rainfall");
    }

    if (humidityScore == 10) {
      reasons.add("Healthy humidity");
    }

    if (windScore == 10) {
      reasons.add("Safe wind conditions");
    }

    if (soilScore == 10) {
      reasons.add("Good estimated soil moisture");
    }

    List<String> warnings = [];

    if (stormScore == 0) {
      warnings.add("Thunderstorm detected");
    }

    if (temperatureScore <= 5) {
      warnings.add("Temperature outside ideal range");
    }

    if (rainfallScore <= 5) {
      warnings.add("Rainfall is insufficient");
    }

    if (windScore <= 5) {
      warnings.add("Strong winds may affect farming");
    }

    return DayScoreResult(
      totalScore: total,
      seasonScore: seasonScore,
      temperatureScore: temperatureScore,
      rainfallScore: rainfallScore,
      humidityScore: humidityScore,
      windScore: windScore,
      stormScore: stormScore,
      soilScore: soilScore,
      level: level,
      reasons: reasons,
      warnings: warnings,
    );
  }

  static int _temperature(double temp) {
    if (temp >= AdvisoryRules.idealMinTemp &&
        temp <= AdvisoryRules.idealMaxTemp) {
      return 20;
    }

    if (temp >= 22 && temp <= 35) {
      return 15;
    }

    return 5;
  }

  static int _rainfall(double rain) {
    if (rain >= 5 && rain <= 20) {
      return 20;
    }

    if (rain > 20 && rain <= 40) {
      return 15;
    }

    if (rain > 0) {
      return 10;
    }

    return 5;
  }

  static int _humidity(int humidity) {
    if (humidity >= AdvisoryRules.idealMinHumidity &&
        humidity <= AdvisoryRules.idealMaxHumidity) {
      return 10;
    }

    return 5;
  }

  static int _wind(double wind) {
    if (wind <= AdvisoryRules.idealMaxWind) {
      return 10;
    }

    if (wind <= 25) {
      return 5;
    }

    return 2;
  }

  static int _soil(
    double rainfall,
    int humidity,
  ) {
    if (rainfall >= 5 && humidity >= 70) {
      return 10;
    }

    if (rainfall >= 2) {
      return 6;
    }

    return 2;
  }
}