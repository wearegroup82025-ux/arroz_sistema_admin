import '../../domain/weather_entity.dart';
import '../../models/guidance_result.dart';

import 'season_service.dart';
import 'planting_score_service.dart';
import 'recommendation_engine.dart';
import 'pest_risk_service.dart';
import 'planting_window_service.dart';
import 'farming_task_service.dart';

class GuidanceController {
  static GuidanceResult generate({
    required WeatherEntity weather,
  }) {
    // 1. Detect current season
    final season = SeasonService.getCurrentSeason();

    // 2. Compute planting score
    final plantingScore = PlantingScoreService.evaluate(
      weather: weather,
      season: season,
    );

    // 3. Generate recommendation
    final recommendation = RecommendationEngine.generate(
      weather: weather,
      plantingScore: plantingScore,
      season: season,
    );

    // 4. Evaluate pest risk
    final pestRisk = PestRiskService.evaluate(
      weather: weather,
      season: season,
    );

    // 5. Find best planting window
    final plantingWindow = PlantingWindowService.generate(
      weather: weather,
      season: season,
    );

    // 6. Generate farming tasks
    final tasks = FarmingTaskService.generate(
      weather: weather,
      season: season,
      pestRisk: pestRisk,
    );

    return GuidanceResult(
      recommendationTitle: recommendation.title,
      recommendationMessage: recommendation.message,
      recommendationAction: recommendation.action,
      confidence: recommendation.confidence,

      plantingScore: plantingScore.totalScore,

      season: season.name,

      pestRisk: pestRisk.level,

      bestPlantingDate: plantingWindow.bestDate,

      goodDays: plantingWindow.goodDays,
      fairDays: plantingWindow.fairDays,
      badDays: plantingWindow.badDays,

      recommendationBasis: recommendation.reasons,

      todayTasks: tasks.map((e) => e.title).toList(),

      seasonalTip: season.tip,

      advisory: recommendation.advisory,
    );
  }
}