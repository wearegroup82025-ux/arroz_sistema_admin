class CropStageResult {
  final int dayNumber;

  final String stage;

  final String description;

  final List<String> recommendedTasks;

  final int daysToHarvest;

  const CropStageResult({
    required this.dayNumber,
    required this.stage,
    required this.description,
    required this.recommendedTasks,
    required this.daysToHarvest,
  });
}

class CropStageService {
  // Average rice duration (120 days)
  static const int cropDuration = 120;

  static CropStageResult evaluate({
    required DateTime plantingDate,
    DateTime? currentDate,
  }) {
    currentDate ??= DateTime.now();

    final day =
        currentDate.difference(plantingDate).inDays + 1;

    int remaining =
        cropDuration - day;

    if (remaining < 0) remaining = 0;

    // -------------------
    // SEEDLING
    // -------------------

    if (day <= 20) {
      return CropStageResult(
        dayNumber: day,
        stage: "Seedling Stage",
        description:
            "Young rice seedlings are establishing roots.",
        recommendedTasks: [
          "Maintain shallow irrigation",
          "Remove weeds",
          "Inspect seedlings",
        ],
        daysToHarvest: remaining,
      );
    }

    // -------------------
    // VEGETATIVE
    // -------------------

    if (day <= 50) {
      return CropStageResult(
        dayNumber: day,
        stage: "Vegetative Stage",
        description:
            "Rapid leaf and tiller development.",
        recommendedTasks: [
          "Apply nitrogen fertilizer",
          "Maintain water level",
          "Monitor weeds",
          "Inspect pests",
        ],
        daysToHarvest: remaining,
      );
    }

    // -------------------
    // REPRODUCTIVE
    // -------------------

    if (day <= 85) {
      return CropStageResult(
        dayNumber: day,
        stage: "Reproductive Stage",
        description:
            "Panicle formation and flowering.",
        recommendedTasks: [
          "Maintain irrigation",
          "Monitor diseases",
          "Avoid water stress",
        ],
        daysToHarvest: remaining,
      );
    }

    // -------------------
    // RIPENING
    // -------------------

    if (day <= cropDuration) {
      return CropStageResult(
        dayNumber: day,
        stage: "Ripening Stage",
        description:
            "Grains are maturing.",
        recommendedTasks: [
          "Reduce irrigation",
          "Monitor grain maturity",
          "Prepare harvesting equipment",
        ],
        daysToHarvest: remaining,
      );
    }

    return const CropStageResult(
      dayNumber: 120,
      stage: "Harvest Ready",
      description:
          "Rice crop is ready for harvesting.",
      recommendedTasks: [
        "Harvest immediately",
      ],
      daysToHarvest: 0,
    );
  }
}