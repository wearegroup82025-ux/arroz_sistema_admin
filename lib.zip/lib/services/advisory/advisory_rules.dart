class AdvisoryRules {
  // ===============================
  // LOCATION
  // ===============================

  static const String location =
      "Capalangan, Apalit, Pampanga";

  // ===============================
  // PHILIPPINE SEASONS
  // ===============================

  static const int wetSeasonStart = 5;   // May
  static const int wetSeasonEnd = 10;    // October

  static const int drySeasonStart = 11;  // November
  static const int drySeasonEnd = 4;     // April

  // ===============================
  // IDEAL RICE GROWING CONDITIONS
  // ===============================

  static const double idealMinTemp = 24.0;
  static const double idealMaxTemp = 32.0;

  static const double idealMinRainfall = 5.0;
  static const double idealMaxRainfall = 20.0;

  static const int idealMinHumidity = 70;
  static const int idealMaxHumidity = 90;

  static const double idealMaxWind = 15.0;

  // ===============================
  // SCORE WEIGHTS
  // ===============================

  static const int seasonWeight = 25;
  static const int temperatureWeight = 20;
  static const int rainfallWeight = 20;
  static const int humidityWeight = 10;
  static const int windWeight = 10;
  static const int stormWeight = 5;
  static const int soilWeight = 10;

  static const int maxScore = 100;
}