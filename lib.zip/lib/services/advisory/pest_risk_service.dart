import '../../domain/weather_entity.dart';
import 'season_service.dart';

class PestRiskResult {
  final String level;
  final String color;
  final String possiblePest;
  final String recommendation;

  const PestRiskResult({
    required this.level,
    required this.color,
    required this.possiblePest,
    required this.recommendation,
  });
}

class PestRiskService {
  static PestRiskResult evaluate({
    required WeatherEntity weather,
    required SeasonResult season,
  }) {
    // Base values
    String level = "Low";
    String color = "green";
    String pest = "No significant pest pressure";
    String recommendation =
        "Continue routine field monitoring.";

    // High humidity + wet season
    if (weather.humidity >= 85 &&
        season.name == "Wet Season") {
      level = "Medium";
      color = "orange";
      pest = "Rice Blast / Leaf Diseases";
      recommendation =
          "Inspect leaves regularly and improve field drainage.";
    }

    // Heavy rain
    if (weather.weatherCode >= 61 &&
        weather.weatherCode <= 67) {
      level = "High";
      color = "red";
      pest = "Rice Blast & Bacterial Leaf Blight";
      recommendation =
          "Delay unnecessary field operations and monitor disease symptoms.";
    }

    // Thunderstorm
    if (weather.weatherCode >= 95) {
      level = "Very High";
      color = "darkred";
      pest = "Severe Crop Stress";
      recommendation =
          "Avoid field work until weather stabilizes.";
    }

    return PestRiskResult(
      level: level,
      color: color,
      possiblePest: pest,
      recommendation: recommendation,
    );
  }
}