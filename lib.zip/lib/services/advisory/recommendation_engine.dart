import '../../domain/weather_entity.dart';
import 'day_score_evaluator.dart';
import 'planting_window_service.dart';

class RecommendationResult {
  final String title;
  final String message;
  final String action;
  final PlantingWindowResult window;
  final DayScoreResult today;

  const RecommendationResult({
    required this.title,
    required this.message,
    required this.action,
    required this.window,
    required this.today,
  });
}
class RecommendationEngine {
  static RecommendationResult generate(
    WeatherEntity weather,
  ) {
    final today = DayScoreEvaluator.evaluate(
      weather: weather,
      day: weather.forecast.first,
    );

    final window =
        PlantingWindowService.evaluate(weather);

    String title;
    String message;
    String action;

    if (today.totalScore >= 90) {
      title = "Excellent Planting Conditions";
      message =
          "Weather conditions are highly favorable for rice planting.";
      action = "Proceed with planting.";
    } else if (today.totalScore >= 75) {
      title = "Good Planting Conditions";
      message =
          "Conditions are generally suitable, but continue monitoring the forecast.";
      action = "Planting is recommended.";
    } else if (today.totalScore >= 60) {
      title = "Fair Conditions";
      message =
          "Conditions are acceptable, but there are some risks.";
      action = "Proceed with caution.";
    } else {
      title = "Poor Planting Conditions";
      message =
          "Weather conditions are currently unfavorable.";
      action = "Delay planting.";
    }

    return RecommendationResult(
      title: title,
      message: message,
      action: action,
      window: window,
      today: today,
    );
  }
}