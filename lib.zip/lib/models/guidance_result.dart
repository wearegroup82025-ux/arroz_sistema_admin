import '../services/advisory/farming_task_service.dart';

class GuidanceResult {

  // Today's Recommendation
  final String recommendationTitle;
  final String recommendationMessage;
  final String recommendationAction;
  final double confidence;

  // Current Farming Conditions
  final double plantingScore;
  final String plantingRating;
  final String season;
  final String pestRisk;

  // Best Planting Window
  final DateTime bestPlantingDate;

  // Weekly Summary
  final int goodDays;
  final int fairDays;
  final int badDays;

  // AI Explanation
  final List<String> recommendationBasis;

  // Activities
  final List<FarmingTask> todayTasks;

  // Seasonal Tip
  final String seasonalTip;

  // Advisory
  final String advisory;

  const GuidanceResult({
    required this.recommendationTitle,
    required this.recommendationMessage,
    required this.recommendationAction,
    required this.confidence,
    required this.plantingScore,
    required this.plantingRating,
    required this.season,
    required this.pestRisk,
    required this.bestPlantingDate,
    required this.goodDays,
    required this.fairDays,
    required this.badDays,
    required this.recommendationBasis,
    required this.todayTasks,
    required this.seasonalTip,
    required this.advisory,
  });
}