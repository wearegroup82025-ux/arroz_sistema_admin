import 'package:flutter/material.dart';

class GuidanceHeader extends StatelessWidget {
  const GuidanceHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF2E7D32),
            Color(0xFF43A047),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.agriculture,
                color: Colors.white,
                size: 38,
              ),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  "Rice Farming Guidance",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          Text(
            "AI-powered farming recommendations for Capalangan, Apalit, Pampanga",
            style: TextStyle(
              color: Colors.white.withOpacity(.9),
              fontSize: 15,
            ),
          ),

          const SizedBox(height: 20),

          Row(
            children: [
              const Icon(
                Icons.location_on,
                color: Colors.white70,
              ),
              const SizedBox(width: 8),
              Text(
                "Capalangan, Apalit, Pampanga",
                style: TextStyle(
                  color: Colors.white.withOpacity(.95),
                ),
              ),
              const Spacer(),
              const Icon(
                Icons.update,
                color: Colors.white70,
              ),
              const SizedBox(width: 6),
              Text(
                "Updated Today",
                style: TextStyle(
                  color: Colors.white.withOpacity(.95),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}