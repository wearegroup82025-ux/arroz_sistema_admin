import 'package:flutter/material.dart';
import '../../../services/advisory/recommendation_engine.dart';

class TodaysRecommendationCard extends StatelessWidget {
  final RecommendationResult recommendation;

  const TodaysRecommendationCard({
    super.key,
    required this.recommendation,
  });

  @override
  Widget build(BuildContext context) {
    final bool good =
        recommendation.today.totalScore >= 80;

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [

            Row(
              children: [

                Icon(
                  good
                      ? Icons.check_circle
                      : Icons.warning_amber_rounded,
                  color:
                      good ? Colors.green : Colors.orange,
                  size: 30,
                ),

                const SizedBox(width: 10),

                const Text(
                  "Today's Recommendation",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            Text(
              recommendation.title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              recommendation.message,
              style: const TextStyle(
                fontSize: 16,
              ),
            ),

            const SizedBox(height: 20),

            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 8,
              ),
              decoration: BoxDecoration(
                color: good
                    ? Colors.green.shade100
                    : Colors.orange.shade100,
                borderRadius:
                    BorderRadius.circular(30),
              ),
              child: Text(
                recommendation.action,
                style: TextStyle(
                  color: good
                      ? Colors.green.shade800
                      : Colors.orange.shade800,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}