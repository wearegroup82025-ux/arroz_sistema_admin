import 'package:flutter/material.dart';
import '../../../models/guidance_result.dart';

class FarmingConditionsCard extends StatelessWidget {
  final GuidanceResult guidance;

  const FarmingConditionsCard({
    super.key,
    required this.guidance,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            const Text(
              "Field Status Overview",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            LayoutBuilder(
              builder: (context, constraints) {

                final isMobile = constraints.maxWidth < 650;

                return Wrap(
                  spacing: 16,
                  runSpacing: 16,
                  children: [

                    _infoCard(
                      Icons.eco,
                      "Planting Score",
                      "${guidance.plantingScore.toInt()}/100",
                    ),

                    _infoCard(
                      Icons.landscape,
                      "Season",
                      guidance.season,
                    ),

                    _infoCard(
                      Icons.bug_report,
                      "Pest Risk",
                      guidance.pestRisk,
                    ),

                    _infoCard(
                      Icons.star,
                      "Rating",
                      guidance.plantingRating,
                    ),

                  ].map((e) {

                    if (isMobile) {
                      return SizedBox(
                        width: constraints.maxWidth,
                        child: e,
                      );
                    }

                    return SizedBox(
                      width: (constraints.maxWidth - 16) / 2,
                      child: e,
                    );

                  }).toList(),
                );
              },
            )
          ],
        ),
      ),
    );
  }

  Widget _infoCard(
    IconData icon,
    String title,
    String value,
  ) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [

          Icon(
            icon,
            size: 34,
            color: Colors.green,
          ),

          const SizedBox(width: 15),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 13,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  value,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),

              ],
            ),
          )
        ],
      ),
    );
  }
}