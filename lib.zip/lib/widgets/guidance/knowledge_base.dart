class KnowledgeBase {
  // Temperature guidance (used as configurable system thresholds)
  static const double idealTempMin = 25.0;
  static const double idealTempMax = 32.0;

  static const double acceptableTempMin = 23.0;
  static const double acceptableTempMax = 34.0;

  // Humidity
  static const double highHumidity = 85.0;

  // Wind Speed (km/h)
  static const double cautionWind = 20.0;
  static const double dangerousWind = 35.0;

  // Rainfall (mm/day)
  static const double lightRain = 5.0;
  static const double moderateRain = 20.0;
  static const double heavyRain = 50.0;

  // Wet season (Philippines)
  static const List<int> wetSeasonMonths = [
    6, 7, 8, 9, 10, 11,
  ];
}