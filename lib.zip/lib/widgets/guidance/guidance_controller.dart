import '../../domain/weather_entity.dart';
import '../../models/guidance_result.dart';
import 'recommendation_engine.dart';
import 'planting_score_service.dart';
import 'season_service.dart';
import 'pest_risk_service.dart';
import 'planting_window_service.dart';
import 'farming_task_service.dart';

class GuidanceController {
  static GuidanceResult generate({
    required WeatherEntity weather,
  }) {
    // 1. Season
    final season = SeasonService.getCurrentSeason();

    // 2. Planting Score
    final score = PlantingScoreService.evaluate(
      weather: weather,
      season: season,
    );

    // 3. Recommendation
    final recommendation = RecommendationEngine.generate(
      weather: weather,
      plantingScore: score,
      season: season,
    );

    // 4. Pest Risk
    final pestRisk = PestRiskService.evaluate(
      weather: weather,
      season: season,
    );

    // 5. Best Planting Window
    final plantingWindow =
        PlantingWindowService.generate(
      weather: weather,
      season: season,
    );

    // 6. Today's Tasks
    final tasks = FarmingTaskService.generate(
      weather: weather,
      season: season,
    );

    return GuidanceResult(
      recommendationTitle: recommendation.title,
      recommendationMessage: recommendation.message,
      recommendationAction: recommendation.action,
      confidence: recommendation.confidence,
      plantingScore: score.totalScore,
      season: season.name,
      pestRisk: pestRisk.level,
      bestPlantingDate:
          plantingWindow.bestDate,
      goodDays:
          plantingWindow.goodDays,
      fairDays:
          plantingWindow.fairDays,
      badDays:
          plantingWindow.badDays,
      recommendationBasis:
          recommendation.reasons,
      todayTasks: tasks,
      seasonalTip:
          season.tip,
      advisory:
          recommendation.advisory,
    );
  }
}