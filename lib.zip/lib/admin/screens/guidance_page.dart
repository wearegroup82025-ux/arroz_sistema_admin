import 'package:flutter/material.dart';

class GuidancePage extends StatelessWidget {
  const GuidancePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Use FutureBuilder to load guidance data asynchronously.
    return FutureBuilder<dynamic>(
      future: GuidanceController.load(),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: \\${snapshot.error}'));
        }
        final data = snapshot.data;
        return Column(
          children: [
            TodaysRecommendationCard(data),
            FarmingConditionCard(data),
            PlantingWindowCard(data),
            SmartCalendarCard(data),
            WeeklyOutlookCard(data),
            TasksCard(data),
            AdvisoryCard(data),
          ],
        );
      },
    );
  }
}